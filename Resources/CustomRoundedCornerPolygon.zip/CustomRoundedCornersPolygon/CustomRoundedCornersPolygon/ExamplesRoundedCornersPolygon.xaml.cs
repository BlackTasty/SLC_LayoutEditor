﻿namespace CustomRoundedCornersPolygon
{
    public partial class ExamplesRoundedCornersPolygon
    {
        public ExamplesRoundedCornersPolygon()
        {
            InitializeComponent();
        }
    }
}
