﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace CustomRoundedCornersPolygon
{
    public partial class RuntimeRoundedCornersControl
    {
        private Polygon _selectedPolygon;
        private RoundedCornersPolygon _roundedPolygon;
        private Path _selectedCornerEllipse;
        private bool _isSelectionVisible;

        public RuntimeRoundedCornersControl()
        {
            InitializeComponent();
            DeleteShapeButton_Click(null, null);
            _isSelectionVisible = true;
        }

        #region Events

        private void Canvas_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (_selectedCornerEllipse != null)
                return;

            var point = e.GetPosition(cnv);
            if (e.ChangedButton == MouseButton.Right && e.ButtonState == MouseButtonState.Pressed)
            {
                _roundedPolygon.IsClosed = true;
            }
            if (e.ChangedButton == MouseButton.Left && e.ButtonState == MouseButtonState.Pressed)
            {
                if (!_roundedPolygon.IsClosed)
                {
                    cnv.Children.Add(GetCornerEllipse(point, _roundedPolygon.Points.Count));
                    _roundedPolygon.Points.Add(point);
                    _selectedPolygon.Points.Add(point);
                }
            }
        }

        private void Canvas_MouseMove(object sender, MouseEventArgs e)
        {
            if (_selectedCornerEllipse == null)
                return;

            var point = e.GetPosition(cnv);

            var geometry = _selectedCornerEllipse.Data as EllipseGeometry;
            if (geometry == null)
                return;

            geometry.Center = point;
            var index = (int)_selectedCornerEllipse.Tag;

            _roundedPolygon.Points[index] = point;
            _selectedPolygon.Points[index] = point;
        }

        private void Canvas_MouseUp(object sender, MouseButtonEventArgs e)
        {
            _selectedCornerEllipse = null;
        }

        private void CornerEllipseMouseUp(object sender, MouseButtonEventArgs e)
        {
            var path = sender as Path;
            if (path == null) return;

            _selectedCornerEllipse = null;
        }

        private void CornerEllipseMouseDown(object sender, MouseButtonEventArgs e)
        {
            var path = sender as Path;
            if (path == null) return;

            _selectedCornerEllipse = path;
        }

        private void AngleComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (_roundedPolygon == null)
                return;

            _roundedPolygon.ArcRoundness = GetSelectedArcRadious();
        }

        private static void CornerEllipseMouseLeave(object sender, MouseEventArgs e)
        {
            var path = sender as Path;
            if (path == null)
                return;
            var geometry = path.Data as EllipseGeometry;
            if (geometry == null)
                return;

            geometry.RadiusX = 4;
            geometry.RadiusY = geometry.RadiusX;
        }

        private static void CornerEllipseMouseEnter(object sender, MouseEventArgs e)
        {
            var path = sender as Path;
            if (path == null)
                return;
            var geometry = path.Data as EllipseGeometry;
            if (geometry == null)
                return;

            geometry.RadiusX = 6;
            geometry.RadiusY = geometry.RadiusX;
        }

        private void GetShapeDataButton_Click(object sender, RoutedEventArgs e)
        {
            PathDataTextBox.Text = _roundedPolygon.Data.ToString();
        }

        private void DeleteShapeButton_Click(object sender, RoutedEventArgs e)
        {
            _selectedPolygon = new Polygon { Stroke = Brushes.Gray, StrokeThickness = 1, StrokeDashArray = new DoubleCollection { 3, 3 } };
            _roundedPolygon = new RoundedCornersPolygon { Stroke = Brushes.Black, StrokeThickness = 1, ArcRoundness = GetSelectedArcRadious(), UseRoundnessPercentage = true, Fill = Brushes.Transparent };

            cnv.Children.Clear();
            cnv.Children.Add(_selectedPolygon);
            cnv.Children.Add(_roundedPolygon);
            PathDataTextBox.Text = string.Empty;
        }

        private void HideShowSelectionButton_Click(object sender, RoutedEventArgs e)
        {
            foreach (Shape shape in cnv.Children)
            {
                if(shape is Path || shape is Polygon) 
                {
                    shape.Visibility = _isSelectionVisible ? Visibility.Hidden : Visibility.Visible;
                }
            }
            _isSelectionVisible = !_isSelectionVisible;
        }

        #endregion

        #region Private Methods

        private Path GetCornerEllipse(Point point, int index)
        {
            var geometry = new EllipseGeometry { Center = point, RadiusX = 4 };
            geometry.RadiusY = geometry.RadiusX;
            var path = new Path { Data = geometry, Fill = Brushes.Gray };
            path.MouseDown += CornerEllipseMouseDown;
            path.MouseUp += CornerEllipseMouseUp;
            path.MouseEnter += CornerEllipseMouseEnter;
            path.MouseLeave += CornerEllipseMouseLeave;
            path.Tag = index;
            return path;
        }

        private double GetSelectedArcRadious()
        {
            return Convert.ToDouble(((ComboBoxItem)AngleComboBox.SelectedValue).Content);
        }

        #endregion
    }
}
