﻿namespace CustomRoundedCornersPolygon
{
    public partial class App
    {
    }
}
